<?php
$config = require_once __DIR__ . '/scripting/config.php'; require_once __DIR__ . '/scripting/functions.php';
$user_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image']))
{
    $description = $_POST['description'] ?? '';
    $result = Upload_Image($_FILES['image'], $description);
    if(isset($result['error']))
    {
        $user_msg = $result['error'];
    }
    else
    {
        $user_msg = "Файл успешно загружен: " . $result['name'];
    }
}
?>
<?php
$images = [];
$jsonFile = $config['json_path'];
if (file_exists($jsonFile)) {
    $images = json_decode(file_get_contents($jsonFile), true) ?: [];
}

$imagesPerPage = $config['images_on_page'];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$totalImages = count($images);
$totalPages = ceil($totalImages / $imagesPerPage);

$start = ($page - 1) * $imagesPerPage;
$imagesOnPage = array_slice($images, $start, $imagesPerPage);
?>


<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Веб-Галерея</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 0; }
header { background: #333; color: #fff; padding: 20px; text-align: center; }
h1 { margin: 0; font-size: 2em; }
form { margin-top: 15px; }
form input[type="file"], form input[type="text"] { padding:5px; margin:5px 0; width: 250px; }
form button { padding:5px 15px; background:#333; color:#fff; border:none; cursor:pointer; }
form button:hover { background:#555; }

.gallery { display:flex; flex-wrap:wrap; justify-content:center; margin:20px; gap:15px; }
.thumb { border:2px solid #ccc; width:300px; overflow:hidden; display:flex; align-items:center; justify-content:center; padding:10px; box-sizing: border-box; background:#fff; flex-direction:column; }
.thumb img { max-width:100%; max-height:220px; object-fit:cover; cursor:pointer; }

.thumb-description { margin-top:5px; font-size:14px; text-align:center;}
.thumb-date { font-size:12px; color:gray; text-align:center}

.pagination { text-align:center; margin:20px; }
.pagination a { margin:0 5px; text-decoration:none; color:#333; padding:5px 10px; border:1px solid #ccc; }
.pagination a.active { background:#333; color:#fff; border-color:#333; }
header { background:#333; color:#fff; padding:20px; text-align:center; }
.upload-form { margin-top:15px; display:flex; flex-wrap:wrap; justify-content:center; gap:10px; align-items:center; }
.upload-form input[type="file"], .upload-form input[type="text"] { padding:5px 6px; border-radius:5px; border:1px solid #ccc; }
.upload-form input[type="text"] { width:200px; }
.upload-btn { background:#28a745; color:#fff; border:none; padding:8px 16px; border-radius:5px; cursor:pointer; transition:background 0.2s; }
.upload-btn:hover { background:#218838; }
</style>
</head>
<body>
<header>
<h1>Загрузка изображения</h1>
<form class="upload-form" action="" method="post" enctype="multipart/form-data">
    <input type="file" name="image" id="image" accept="image/.jpeg, .jpg, .png, .gif" required>
    <input type="text" name="description" id="description" maxlength="255" placeholder="Описание изображения">
    <button type="submit" class="upload-btn">Загрузить</button>
</form>
<?php if (!empty($user_msg)) : ?>
    <p><?php echo htmlspecialchars($user_msg); ?></p>
<?php endif; ?>
</header>

<hr>
<h2 style="text-align:center;">Галерея</h2>
<div class="gallery">
<?php foreach ($imagesOnPage as $img): ?>
    <div class="thumb">
        <a href="<?php echo htmlspecialchars($img['path']); ?>" target="_blank">
            <img src="<?php echo htmlspecialchars($img['thumbnail']); ?>" alt="<?php echo htmlspecialchars($img['description']); ?>">
        </a>
        <div class="thumb-description"><?php echo htmlspecialchars($img['description']); ?></div>
        <div class="thumb-date"><?php echo htmlspecialchars($img['uploaded_at']); ?></div>
    </div>
<?php endforeach; ?>
</div>

<div class="pagination">
<?php if($page > 1): ?>
    <a href="?page=<?php echo $page-1; ?>">&laquo; Назад</a>
<?php endif; ?>
<?php for($i = 1; $i <= $totalPages; $i++): ?>
    <a href="?page=<?php echo $i; ?>" class="<?php if($i==$page) echo 'active'; ?>"><?php echo $i; ?></a>
<?php endfor; ?>
<?php if($page < $totalPages): ?>
    <a href="?page=<?php echo $page+1; ?>">Вперед &raquo;</a>
<?php endif; ?>
</div>

</body>
</html>