<?php
$config = require 'config.php'; require 'functions.php';

$some_name = CreateUniqueFileName($config['images_dir'], 'cat.png');
file_put_contents($config['images_dir'] . $some_name, '');
