<?php
// конфигурация галереи. нужна для работы в других скриптах.

if (!defined('SERVER_ROOT_DIR')) 
{
    define('SERVER_ROOT_DIR', dirname(__DIR__));
}

return [
    // вызов этого скрипта в другом месте возвращает массив

    // директории/пути
    'images_dir' => SERVER_ROOT_DIR . '/upload/img_full/',
    'thumbnails_dir' => SERVER_ROOT_DIR . '/upload/img_thumbnails/',
    'json_path' => SERVER_ROOT_DIR . '/data/images.json',
    'watermark_path' => SERVER_ROOT_DIR . '/assets/watermark.png',
    'fonts' => [
        'Jura' => ['label' => 'Jura', 'path' => SERVER_ROOT_DIR . '/assets/fonts/Jura.ttf'],
        'Cormorant' => ['label' => 'Cormorant', 'path' => SERVER_ROOT_DIR . '/assets/fonts/Cormorant.ttf'],
        'RubikBubbles' => ['label' => 'RubikBubbles', 'path' => SERVER_ROOT_DIR . '/assets/fonts/RubikBubbles.ttf']
    ],
    'postcards_dir' => SERVER_ROOT_DIR . '/upload/postcards',

    // настройки
    'thumbnail_size' => 300,
    'max_file_size' => 12 * 1024 * 1024,
    'allowed_types' => ['image/jpeg', 'image/png', 'image/gif'],
    'images_on_page' => 9
];