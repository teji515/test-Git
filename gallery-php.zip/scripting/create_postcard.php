<?php
$config = require_once 'config.php';

$image = isset($_POST['image']) ? basename($_POST['image']) : '';
$fontFile = isset($_POST['font']) ? basename($_POST['font']) : 'Jura.ttf';
$text = isset($_POST['text']) ? trim($_POST['text']) : '';

if ($image === '') die('No image');
if ($text === '') $text = 'Поздравляю!';

$input = $config['images_dir'] . $image;

$fontKey = pathinfo($fontFile, PATHINFO_FILENAME);
$fontPath = $config['fonts'][$fontKey]['path'] ?? $config['fonts']['Jura']['path'];

$outDir = $config['postcards_dir'];
if (!is_dir($outDir)) mkdir($outDir, 0777, true);

$info = @getimagesize($input);
if (!$info) die('Not an image');

switch ($info['mime']) {
    case 'image/jpeg': $img = imagecreatefromjpeg($input); break;
    case 'image/png':  $img = imagecreatefrompng($input); break;
    case 'image/gif':  $img = imagecreatefromgif($input); break;
    default: die('Unsupported format');
}
if (!$img) die('Open fail');

//gd
$size = 36;
$angle = 0;
$imgW = imagesx($img);
$imgH = imagesy($img);
$bbox = imagettfbbox($size, $angle, $fontPath, $text);
$textW = abs($bbox[2] - $bbox[0]);
$centerX = intval(($imgW - $textW) / 2);
$marginBottom = 30;
$y = $imgH - $marginBottom;
$textH = abs($bbox[7] - $bbox[1]);
if ($y < $textH + 10) $y = intval(($imgH + $textH) / 2);

$white = imagecolorallocate($img, 255, 255, 255);
imagettftext($img, $size, $angle, $centerX, $y, $white, $fontPath, $text);

$ext = pathinfo($image, PATHINFO_EXTENSION);
$outName = 'postcard_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
$outPath = $outDir . '/' . $outName;

switch ($info['mime']) {
    case 'image/jpeg': imagejpeg($img, $outPath); break;
    case 'image/png':  imagepng($img, $outPath); break;
    case 'image/gif':  imagegif($img, $outPath); break;
}

imagedestroy($img);

$public = str_replace($config['images_dir'], '/upload/img_full/', $input); // для изображения
$publicPostcard = str_replace($config['postcards_dir'], '/upload/postcards/', $outPath);

echo "<h3>Готово</h3>";
echo "<img src='" . htmlspecialchars($publicPostcard) . "' style='max-width:600px; display:block; margin-bottom:8px;'>";
echo "<a href='" . htmlspecialchars($publicPostcard) . "' download>Скачать</a>";